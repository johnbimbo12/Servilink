<?php

use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
 */
Route::get('/run/command', [App\Http\Controllers\AdminController::class, 'command']);

Route::post('/pay/webhook', [App\Http\Controllers\PaymentGatewayController::class, 'transferwebhook']);
Route::post('/initialize', [App\Http\Controllers\API\MobileController::class, 'initialize']);
Route::post('/verify', [App\Http\Controllers\API\MobileController::class, 'verify']);
Route::post('/callback', [App\Http\Controllers\API\MobileController::class, 'callback'])->name('api.callback');

Route::post('/auth/login', [App\Http\Controllers\API\AuthController::class, 'login']);
Route::post('/auth/logout', [App\Http\Controllers\API\AuthController::class, 'logout']);
Route::get('/user', [App\Http\Controllers\API\AuthController::class, 'userData']);

Route::get('/vend/history', [App\Http\Controllers\API\MobileController::class, 'vendHistory']);
Route::get('/vending/details', [App\Http\Controllers\API\MobileController::class, 'VendingDetails']);
Route::get('/pay/history', [App\Http\Controllers\API\MobileController::class, 'payHistory']);


Route::get('/transaction', [App\Http\Controllers\API\MobileController::class, 'Transactions']);
Route::get('/notification', [App\Http\Controllers\API\MobileController::class, 'Notification']);


Route::post('/book/visitor', [App\Http\Controllers\API\MobileController::class, 'BookVisit']);
Route::get('/visit/history', [App\Http\Controllers\API\MobileController::class, 'GetVisits']);

Route::post('/submit/request', [App\Http\Controllers\API\MobileController::class, 'SubmitRequest']);
Route::get('/get/request', [App\Http\Controllers\API\MobileController::class, 'GetRequest']);
Route::get('/request/details', [App\Http\Controllers\API\MobileController::class, 'RequestDetails']);

Route::post('/update/password', [App\Http\Controllers\API\MobileController::class, 'updatePassword']);
Route::post('/update/phonenumber', [App\Http\Controllers\API\MobileController::class, 'updatePhone']);
Route::post('/update/email', [App\Http\Controllers\API\MobileController::class, 'updateEmail']);

Route::post('/emergency/alert', [App\Http\Controllers\API\MobileController::class, 'emergencyAlert']);
Route::post('/emergency/contact', [App\Http\Controllers\API\MobileController::class, 'postEmergencyContact']);
Route::get('/emergency/contact', [App\Http\Controllers\API\MobileController::class, 'getEmergencyContact']);
Route::post('/emergency/delete', [App\Http\Controllers\API\MobileController::class, 'deleteEmergencyContact']);

Route::post('/book/space', [App\Http\Controllers\API\MobileController::class, 'BookSpace']);
Route::get('/get/bookings', [App\Http\Controllers\API\MobileController::class, 'BookingHistory']);
Route::get('/booking/details', [App\Http\Controllers\API\MobileController::class, 'BookingDetails']);
Route::get('/load/venue', [App\Http\Controllers\API\MobileController::class, 'LoadSpace']);
Route::get('/available/date', [App\Http\Controllers\API\MobileController::class, 'availablespace']);
