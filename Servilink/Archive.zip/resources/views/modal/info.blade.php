<!-- Modal -->
<div class="modal fade" id="modal-info" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          
            <div class="modal-body">
                <div class="container">
                    <h2 style="font-weight: bold">Coming soon....</h2>
                </div>
            </div> {{-- Modal Body --}}
        </div> {{-- End Modal Dialog --}}
    </div> {{-- End Modal --}}
</div>