<?php

namespace App\Http\Controllers;

use App\Helpers\HelperClass;
use App\Models\Managers;
use App\Models\User;
use App\Models\Withdrawals;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Ramsey\Uuid\Type\Decimal;
use Yajra\DataTables\Facades\DataTables;

class WithdrawalsController extends Controller
{

    public function RequestWithdraw(Request $request)
    {
        $user = Auth::user();
        $manager = Managers::where('user_id', $user->id)->first();
        $payout_by = ($user->role == 1) ? "Hinge Management" : "Servilink Management";
        if ($manager->earning > $request->amount) {
            $withdraw = new Withdrawals();
            $withdraw->amount = $request->amount;
            $withdraw->status = false;
            $withdraw->bank_name = $request->bank;
            $withdraw->sent_to = $payout_by;
            $withdraw->account_number = $request->account_number;
            $withdraw->manager_id = $user->id;
            $withdraw->save();
            $manager->decrement('earning',  $request->amount);
            $msg = $manager->name . " Requested for N$request->amount";
            if ($user->role == 1) {
                # code...
                HelperClass::sendEmail("emmaodunlade@gmail.com", "Withdrawal Request from inflow wallet", $msg);
                HelperClass::sendEmail("raysamtob@gmail.com", "Withdrawal Request from inflow wallet", $msg);
            } else {
                HelperClass::sendEmail("bumsyyd@gmail.com", "Withdrawal Request from inflow wallet", $msg);
            }
            return redirect()->back()->with("success", "Request sent");
        } else {
            return redirect()->back()->with("info", "Requested amount is leass than the earning balance");
        }
    }



    public function WithdrawAdminLog(Request $request)
    {

        $user_id = Auth::id();
        $from = $request->start_date;
        $to = $request->end_date;
        $start = Carbon::parse($from);
        $end = Carbon::parse($to)->addDay();
        $this_month = [$start, $end];
        $withdraw = Withdrawals::whereBetween('created_at', $this_month)->orderBy('id', 'asc')->get();
        $balance = Managers::where('user_id', $user_id)->value('earning');
        $totalwithdraw = Withdrawals::where("manager_id", $user_id)->sum('amount');
        foreach ($withdraw as $key => $value) {
            $value->name = User::where('id', $value->manager_id)->value('name');
            $value->transdate = Carbon::parse($value->created_at)->format('Y-m-d H:m:s');
        }
        if (request()->ajax()) {
            return DataTables::of($withdraw)
                ->addIndexColumn()
                ->addColumn('action', function ($row) {
                    $btn = '
                     <a class="confirmpayout" href="' . route('update.payout', ["id" => $row->id]) . '" data-id="' . $row->id . '" data-placement="top" title="payout" ><i class="fa fa-edit text-success" style="cursor: pointer"> Confirm Payout</i></a>
                     &nbsp; &nbsp;
                     ';
                    return $btn;
                })
                ->rawColumns(['action'])
                ->make(true);
        }
        $banks = DB::table('banks')->get();
        return view('admin.withdraws', compact('balance', 'totalwithdraw', 'banks'));
    }

    public  function UpdatePayout($id)
    {
        $withdraw = Withdrawals::find($id);
        $withdraw->status = true;
        $withdraw->update();
        return redirect()->back()->with("success", "Payout confimred status updated successfully");
    }
    public function WithdrawLog(Request $request)
    {
        $user_id = Auth::id();
        $from = $request->start_date;
        $to = $request->end_date;
        $start = Carbon::parse($from);
        $end = Carbon::parse($to)->addDay();
        $this_month = [$start, $end];
        $balance = Managers::where('user_id', $user_id)->value('earning');
        $withdraw = Withdrawals::where("manager_id", $user_id)->whereBetween('created_at', $this_month)->orderBy('id', 'asc')->get();
        $totalwithdraw = Withdrawals::where("manager_id", $user_id)->sum('amount');
        foreach ($withdraw as $key => $value) {
            $value->transdate = Carbon::parse($value->created_at)->format('Y-m-d H:m:s');
        }
        if (request()->ajax()) {
            return DataTables::of($withdraw)
                ->make(true);
        }
        $banks = DB::table('banks')->get();
        return view('manager.withdraws', compact('balance', 'totalwithdraw', 'banks'));
    }
}
