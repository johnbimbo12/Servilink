<?php

namespace App\Http\Controllers;

use App\Helpers\HelperClass;
use App\Models\PaymentGateway;
use App\Models\ChargesPayment;

use App\Models\VendingTransaction;
use App\Models\User;
use App\Models\Estate;
use App\Models\estateuser;
use App\Models\Inflows;
use App\Models\PaymentTransact;
use Illuminate\Support\Facades\Http;
use App\Models\Setting;
use Carbon\Carbon;
use App\Models\Managers;
use App\Models\Notification;
use App\Models\ServiceAccount;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Session;
use Unicodeveloper\Paystack\Facades\Paystack;

class PaymentGatewayController extends Controller
{


    public function redirectToGateway(Request $request)
    {

        $customer_email = $request->email;
        $amount = $request->amount; //converting to kobo - paystack rule
        $package = "basic";
        $reference = Paystack::genTranxRef();
        $kobo = ($amount) * 100; //add the user inputted amount and the outstanding fees
        $metadata = ['customer_id' => 1, 'client_id' => 12, 'package' => $package]; //metadata for the data i need
        $request->request->add(['reference' => $reference, 'email' => $customer_email, 'amount' => $kobo, 'currency' => 'NGN', 'channels' => ['card', 'bank_transfer'], 'metadata' => $metadata, 'callback_url' => env('APP_URL') . 'payment/callback']);
        try { //to ensure the page return back to the user when the session has expired
            return Paystack::getAuthorizationUrl()->redirectNow();
        } catch (\Exception $e) {
            \Log::info($e);
            return \response()->json(["id" => "error", "msg" => "Error occur while access payment gateway, please try again!!!"]);
        }
    }

    /**
     * Obtain Paystack payment information
     * @return void
     */
    public function handleGatewayCallback()
    {
        $paymentDetails = Paystack::getPaymentData();

        \Log::info($paymentDetails);
        if ($paymentDetails['status'] == true) {
            \Log::info($paymentDetails['data']);

            \Log::info($paymentDetails['data']['metadata']);
            \Log::info($paymentDetails['data']['metadata']['customer_id']);

            dd($paymentDetails['data']['metadata']['customer_id']);
        }

        // Now you have the payment details,
        // you can store the authorization_code in your db to allow for recurrent subscriptions
        // you can then redirect or do whatever you want
    }

    public function checkMeter($request)
    {
        set_time_limit(0);
        $meterPAN = $request['meternumber'];
        $amount = $request['amount'];
        $vendamt = $amount;
        $eUser = estateuser::where('meternumber', $meterPAN)->first();
        $manager_user_id = $eUser->manager_user_id;

        $serviceact = ServiceAccount::where('manager_user_id', $manager_user_id)->where('service_type', 0)->first();
        $accountname = $serviceact->account_name;
        $accountnum = $serviceact->account_number;
        $bankname = $serviceact->bank;

        $txref = HelperClass::generateReference("PW");
        $request["user"] = $eUser;
        $request["customer_ref"] = $txref;
        $request["txref"] = $txref;
        $request["manager_id"] = $manager_user_id;
        $request["accountname"] = $accountname;
        $request["accountnum"] = $accountnum;
        $request["bankname"] = $bankname;
        $vendamt = $vendamt - 100; // remove vending fee from amount user went to buy
      
        if ($eUser->verified == 1) {
            $transact = new PaymentTransact();
            $transact->payerid = $eUser->user_id;
            $transact->path = 3;
            $transact->txref = $txref;
            $transact->amount = (int) $amount;
            $transact->category = 0;
            $transact->charged_amt = 200;
            $transact->customer = json_encode($request);
            $transact->vend_value = $vendamt;
            $transact->merchant = $manager_user_id;
            $transact->payment_status = "Processing";
            $transact->save();
            $amount = $amount + 200; // add payment gateway transaction fee to amoun to pay
            return response()->json([
                "status" => "ok",
                "amount" => $amount,
                "txref" => $txref,
                "manager_id" => $manager_user_id,
                "accountname" => $accountname,
                "accountnum" => $accountnum,
                "bankname" => $bankname,
                "msg" => "proceed",
            ]);
        }

        try {
            $params = [];
            $url = config('hinge.hingeurl') . "check_meter";
            $params['access_key'] = config('hinge.hingekey');
            $params['meternumber'] = $meterPAN;
            $resp = Http::withOptions(["verify" => true])
                ->post($url, $params);
            Log::info($resp);
            $resp = json_decode($resp);
            
            $vendamt = $vendamt - 100; // remove vending fee from amount user went to buy
         
            if ($resp->status == "ok") {
                $response = json_decode($resp->msg);
                if ($response->statusCode == "0") {
                    $eUser->verified = 1;
                    $eUser->update();
                    $transact = new PaymentTransact();
                    $transact->payerid = $eUser->user_id;
                    $transact->path = 4;
                    $transact->channel = 2;
                    $transact->txref = $txref;
                    $transact->amount = (int) $amount;
                    $transact->vend_value = $vendamt;
                    $transact->charged_amt = 200;
                    $transact->customer = json_encode($request);
                    $transact->vend_value = $vendamt;
                    $transact->merchant = $manager_user_id;
                    $transact->payment_status = "Processing";
                    $transact->save();

                    $amount = $amount + 200; // add payment gateway transaction fee to amoun to pay
                    return response()->json([
                        "status" => "ok",
                        "amount" => $amount,
                        "txref" => $txref,
                        "manager_id" => $manager_user_id,
                        "accountname" => $accountname,
                        "accountnum" => $accountnum,
                        "bankname" => $bankname,
                        "msg" => "proceed",
                    ]);
                } else {
                    return response()->json([
                        "status" => "info",
                        "msg" => "Error occur verifing customer",
                    ]);
                }
            }
        } catch (\Throwable $th) {
            Log::error($th);
            return response()->json([
                "status" => "info",
                "msg" => "Error occur verifing customer",
            ]);
        }
    }
    public function verifyCustomer(Request $request)
    {
        $input = $request->all();
        $meterPAN = $request->meternumber;
        $eUser = estateuser::where('meternumber', $meterPAN)->first();
        if ($eUser) {
            if ($input['product'] == "power") {
                $amount = (int) $request->amount;
                if ($eUser->status == 0) {
                    Session::put('error', "Account is locked,Contact the manager, Thanks");
                    return response()->json([
                        "status" => "info",
                        "msg" => "Account is locked,Contact the manager, Thanks",
                    ]);
                }
                $manageruser_id = $eUser->manager_user_id;
                $minVend = Setting::where('manager_user_id', $manageruser_id)->value('min_vend');
                if ($amount < $minVend) {
                    Session::put('error', "Minimim amount to buy is NGN" . $minVend . ", Thanks");
                    return response()->json([
                        "status" => "info",
                        "msg" => "Minimim amount to buy is NGN" . $minVend . ", Thanks",
                    ]);
                }
                $estate = Estate::where('id', $eUser->estate_id)->first();
                $estateChg = $estate->service_charge;
                $xMonth = $estate->exipre_tolerance;
                if ((int) $estateChg > 0.00) {
                    $cPayment = ChargesPayment::where('meternumber', $meterPAN)->orderBy('id', 'desc')->first();
                    if ($cPayment == null) {
                        Session::put('error', "Service charge fee payment pending, please make payment, Thanks");
                        return response()->json([
                            "status" => "info",
                            "msg" => "Service charge fee payment pending, please make payment, Thanks",
                        ]);
                    }

                    $payday = $cPayment->payment_date;
                    $expireDate = Carbon::parse($payday)->subDay()->format('Y-m-d');
                    $today = date("Y-m-d");
                    $exDate = date('Y-m-d', strtotime($expireDate));
                    $nowDate = date('Y-m-d', strtotime($today));
                    if ($nowDate > $exDate) {
                        Session::put('error', "Service charge fee payment pending, please make payment, Thanks");
                        return response()->json([
                            "status" => "info",
                            "msg" => "Service charge fee payment pending, please make payment, Thanks",
                        ]);
                    }
                }
                return $this->checkmeter($input);
            } else {

                $amount = $request->scamount;
                $paid_month = $request->nummonth;
                $manager_user_id = $eUser->manager_user_id;
                $txref = HelperClass::generateReference("SC");
                $setting = Setting::where('manager_user_id', $manager_user_id)->first();

                $service_fee = $setting->service_trans_fee;
                $platform_fee = ($setting->transaction_fee) * $paid_month;
                $transaction_fee = $service_fee + $platform_fee;
                $estate_amount = $amount - ($transaction_fee);
                $eUser->paid_month = $paid_month;

                $serviceact = ServiceAccount::where('manager_user_id', $manager_user_id)->where('service_type', 1)->first();
                $accountname = $serviceact->account_name;
                $accountnum = $serviceact->account_number;
                $bankname = $serviceact->bank;

                $input["user"] = $eUser;
                $input["txref"] = $txref;
                $input["manager_id"] = $manager_user_id;
                $input["accountname"] = $accountname;
                $input["accountnum"] = $accountnum;
                $input["bankname"] = $bankname;
        
                $transact = new PaymentTransact();
                $transact->payerid = $eUser->user_id;
                $transact->txref = $txref;
                $transact->amount = (int) $amount;
                $transact->vend_value = $estate_amount;
                $transact->channel = 2;
                $transact->path = 4;
                $transact->charged_amt = $transaction_fee;
                $transact->customer = json_encode($input);
                $transact->merchant = $manager_user_id;
                $transact->category = 1;
                $transact->payment_status = "Processing";
                $transact->save();
             
                $amount = $amount + 200; // plus bani gateway fee 
                return response()->json([
                    "status" => "ok",
                    "amount" => $amount,
                    "txref" => $txref,
                    "manager_id" => $manager_user_id,
                    "accountname" => $accountname,
                    "accountnum" => $accountnum,
                    "bankname" => $bankname,
                    "msg" => "proceed",
                ]);
            }
        } else {
            Session::put('error', "Meter not found, please contact the administrator, Thanks");
            return response()->json([
                "status" => "info",
                "msg" => "Meter not found, please contact the administrator, Thanks",
            ]);
        }
    }

    public function verifyPayment(Request $request)
    {
        Log::info($request);
        $txref = $request->customer_ref;
        $paytrans = PaymentTransact::where('txref', $txref)->first();
        $service =  $paytrans->category;
        if ($paytrans->payment_status == "successful") {
            if ($paytrans->service_status == 1) {
                if ((int)$service == 0) {
                    $path = $paytrans->path;
                    $vendTran = VendingTransaction::where("txref", $txref)->first();
                    $token = $vendTran->token;
                    $message = "Purchase successfull, here is your token: " . $token;
                    if ($path == 2) {
                        return redirect()->route('power.manage')->with("success", $message);
                    } else if ($path == 3) {
                        return response()->json(route('feedback', ['status' => 'ok', 'msg' => $message]));
                    }
                } else {
                    $message = "Service payment was successfull";
                }
            } else {
                $message = "Payment was successfull,  You will get Email notification ofthe service delivery";
            }
            return response()->json(route('feedback', ['status' => 'ok', 'msg' => $message]));
        }
        else if ($paytrans->payment_status == "on_going") {
            $message = "Payment status is on_going. Amount transfer was not complete. Kindly complete your payment ";
            return response()->json(route('feedback', ['status' => 'ok', 'msg' => $message]));
        }  
        else {
            $message = "Payment still in progress. You will get Email notification once complete";
            return response()->json(route('feedback', ['status' => 'ok', 'msg' => $message]));
        }
    }

    public function transferwebhook(Request $request)
    {
        Log::info($request);
        $txref = $request->txref;
        $pay_ref = $request->pay_ref;
        $customer =  $request->customer;
        $pay_status = $request->pay_status;
        try {
            $paytrans = PaymentTransact::where('txref', $txref)->first();
            if (!$paytrans) {
                return;
            }
            if ($paytrans->service_status == 1) {
                return;
            }
            if ($pay_status == "paid" || $pay_status == "completed") {
                $service =   $paytrans->category;
                $meter_number = $customer["meternumber"];
                $paytrans->payment_status = "successful";
                $paytrans->pay_ref =  $pay_ref;
                $paytrans->update();
                $manager_id = $paytrans->merchant;
                $vendamt = $paytrans->vend_value;
                $user = User::where('id', $paytrans->payerid)->first();

                // Log Transaction
                $manager = Managers::where('user_id', $manager_id)->first();
                $manager->increment('earning',  $vendamt);
                $admin = Managers::where('user_id', 1)->first();
                $admin->increment('earning',  $vendamt);
                $inflowsTrans = new Inflows();
                $inflowsTrans->manager_id = $manager_id;
                $inflowsTrans->amount = $vendamt;
                $inflowsTrans->payref = $pay_ref;
                $inflowsTrans->category = $service;
                $inflowsTrans->save();

                if ((int)$service == 0) {

                    return  app('App\Http\Controllers\PowerManagerController')->VendUnit($meter_number, $txref, $manager_id);
                } else {
                    $paid_month = $customer["nummonth"];
                    $estate = $customer["estateid"];
                    $phone = $customer["phonenumber"];
                    $from = Carbon::now()->endOfMonth();
                    $to = Carbon::today();
                    $diff_in_days = $to->diffInDays($from);
                    $lastpaydate = Carbon::today()->endOfMonth()->addMonths($paid_month)->format("Y-m-d");
                    if ($diff_in_days > 10) {
                        $lastpaydate = Carbon::today()->startOfMonth()->addMonths($paid_month)->endOfMonth()->format("Y-m-d");
                    }
                    $paydate = ChargesPayment::where('meternumber', $meter_number)->orderBy('id', 'desc')->value('payment_date');
                    if ($paydate) {
                        $lastpaydate = Carbon::parse($paydate)->addMonths($paid_month)->endOfMonth()->format("Y-m-d");
                    }
                    $paytrans->service_status = 1;
                    $paytrans->update();
                    $charged = new ChargesPayment();
                    $charged->estate_id = $estate;
                    $charged->phonenumber = $phone;
                    $charged->meternumber = $meter_number;
                    $charged->txref = $txref;
                    $charged->user_id = $paytrans->payerid;
                    $charged->amount = $vendamt;
                    $charged->email = $user->email;
                    $charged->payment_date = $lastpaydate;
                    $charged->no_of_month = $paid_month;
                    $charged->save();
                    $notify = new Notification();
                    $notify->user_id = $paytrans->payerid;
                    $notify->type = 1;
                    $notify->notify_msg = $paid_month . " month(s) service charge payment was successful.";
                    $notify->save();
                }
            } else {
                $paytrans->payment_status = $pay_status;
                $paytrans->pay_ref =  $pay_ref;
                $paytrans->update();
            }
        } catch (\Throwable $th) {
            Log::info($th);
        }
        return response()->json('Ok');
    }
}
