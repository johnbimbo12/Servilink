<?php
return [

    'hingekey' => env('HINGE_ACCESS_KEY'),

    'hingeurl' => env('HINGE_BASE_URL'),
    
    'share_account' => env('HINGE_SHARE_ACCOUNT'),
];